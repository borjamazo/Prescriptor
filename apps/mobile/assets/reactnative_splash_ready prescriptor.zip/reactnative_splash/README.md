# Splash screen (React Native)

Este paquete está preparado para **react-native-bootsplash** (bare RN / RN CLI).

## 1) Instalar

```bash
yarn add react-native-bootsplash
# o
npm i react-native-bootsplash
```

iOS:

```bash
cd ios && pod install && cd ..
```

## 2) Generar splash (Android + iOS)

Desde la raíz del proyecto:

```bash
npx react-native generate-bootsplash ./assets/bootsplash_logo.png \
  --background-color=FFFFFF \
  --logo-width=220 \
  --platforms=android,ios
```

> Si quieres el logo más grande/pequeño ajusta `--logo-width`.

## 3) Verificación rápida

- Android: revisa que se hayan creado/actualizado `android/app/src/main/res/drawable*` y `values*`
- iOS: revisa `ios/<TuApp>/BootSplash.storyboard` y assets relacionados

## Contenido

- `assets/bootsplash_logo.png` (tu logo)
- `bootsplash.config.js` (valores recomendados)

